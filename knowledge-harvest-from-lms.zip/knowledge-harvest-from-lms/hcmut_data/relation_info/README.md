GROUP 1
    course → has_assessment_method → exam
    subject → has_assessment_method → project
    curriculum → has_assessment_method → assessment_tool
