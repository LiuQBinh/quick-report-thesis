- dựng tập data để train từ output entity, relation từ thầy  (90%)
    - train thử (99%)
    - thế hcmut entity vào data đã dựng
    - dọc paper khảo sát data (advance)
- viết báo cáo
    - report (5%)
    - slide (0%)

